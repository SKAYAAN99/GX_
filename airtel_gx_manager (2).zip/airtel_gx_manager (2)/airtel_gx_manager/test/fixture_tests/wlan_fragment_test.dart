// wlan_fragment_test.dart
//
// Tests WlanFragmentParser against a hand-built fixture. IMPORTANT: per
// the comment in router_service.dart, the field names here (SSID,
// EnableSSID, EncryptionType) are NOT confirmed against real firmware —
// static analysis of net-wlan.asp showed the SSID input isn't in the
// page's static HTML at all. This test verifies the *regex extraction
// logic* behaves correctly (matches when present, returns null instead
// of throwing when absent) — it is not evidence the parser works
// against a real router yet. Replace the fixture below with an actual
// captured page before trusting this feature.

import 'package:flutter_test/flutter_test.dart';
import 'package:airtel_gx_manager/services/router_service.dart';

void main() {
  group('WlanFragmentParser', () {
    test('extracts SSID, broadcast state, and security type when present',
        () {
      const fixture = '''
        <form name="ConfigForm">
          <input type="text" name="SSID" value="Airtel_GX_5G">
          <input type="checkbox" name="EnableSSID" checked>
          <select name="EncryptionType">
            <option value="WPA2-PSK" selected>WPA2-PSK</option>
            <option value="Open">Open</option>
          </select>
        </form>
      ''';

      final result = WlanFragmentParser.parse(fixture);

      expect(result, isNotNull);
      expect(result!.ssid, 'Airtel_GX_5G');
      expect(result.broadcastEnabled, isTrue);
      expect(result.securityType, 'WPA2-PSK');
    });

    test('returns null instead of throwing when SSID field is missing (e.g. '
        'a different firmware build, or the runtime-JS-rendered case noted '
        'in router_service.dart)', () {
      const fixture = '<html><body>Not a WLAN page</body></html>';

      final result = WlanFragmentParser.parse(fixture);

      expect(result, isNull);
    });

    test('treats an unchecked broadcast checkbox as disabled without '
        'crashing on the missing attribute', () {
      const fixture = '''
        <input type="text" name="SSID" value="Guest_Network">
        <input type="checkbox" name="EnableSSID">
      ''';

      final result = WlanFragmentParser.parse(fixture);

      expect(result, isNotNull);
      expect(result!.broadcastEnabled, isFalse);
      expect(result.securityType, isNull);
    });
  });
}
