// dashboard_feature_card.dart
//
// Adding a new dashboard feature (Speed Test, Port Forwarding, Parental
// Controls, ...) should mean appending one DashboardFeatureConfig to a
// list — not touching this widget or the grid layout. See
// dashboard_screen.dart for the config list itself.

import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class DashboardFeatureConfig {
  final String title;
  final IconData icon;
  final VoidCallback onTap;

  /// Features not wired up yet render disabled with this label instead
  /// of just vanishing from the grid — keeps the grid's shape stable
  /// as features come online one at a time.
  final bool enabled;
  final String? disabledLabel;

  const DashboardFeatureConfig({
    required this.title,
    required this.icon,
    required this.onTap,
    this.enabled = true,
    this.disabledLabel,
  });
}

class DashboardFeatureCard extends StatelessWidget {
  final DashboardFeatureConfig config;
  const DashboardFeatureCard({super.key, required this.config});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: config.enabled ? config.onTap : null,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                config.icon,
                size: 28,
                color: config.enabled ? AppColors.actionBlue : Colors.grey,
              ),
              const SizedBox(height: 12),
              Text(
                config.title,
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: config.enabled ? AppColors.navy : Colors.grey,
                ),
              ),
              if (!config.enabled && config.disabledLabel != null) ...[
                const SizedBox(height: 4),
                Text(
                  config.disabledLabel!,
                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

/// The grid itself — also reusable. Takes the config list and lays it
/// out responsively; adding a 5th, 6th, 7th feature just reflows.
class DashboardFeatureGrid extends StatelessWidget {
  final List<DashboardFeatureConfig> features;
  const DashboardFeatureGrid({super.key, required this.features});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: EdgeInsets.zero,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.3,
      ),
      itemCount: features.length,
      itemBuilder: (context, i) => DashboardFeatureCard(config: features[i]),
    );
  }
}
