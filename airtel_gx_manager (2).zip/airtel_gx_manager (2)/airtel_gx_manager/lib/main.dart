// main.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/session_controller.dart';
import 'theme/app_theme.dart';
import 'screens/login_screen.dart';
import 'screens/dashboard_screen.dart';

void main() {
  runApp(const AirtelGxManagerApp());
}

class AirtelGxManagerApp extends StatelessWidget {
  const AirtelGxManagerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => SessionController(),
      child: MaterialApp(
        title: 'GIC Broadband',
        theme: AppTheme.light,
        home: const RootRouter(),
      ),
    );
  }
}

/// Watches SessionController.status and shows the right screen —
/// discovery spinner, "not found" retry, login, or the dashboard.
/// Kept as a single small widget rather than a full named-route table
/// since the flow is strictly linear (no deep linking needed for a
/// LAN admin app).
class RootRouter extends StatelessWidget {
  const RootRouter({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<SessionController>();

    switch (controller.status) {
      case SessionStatus.discovering:
        return const Scaffold(
          body: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 16),
                Text('Looking for your router…'),
              ],
            ),
          ),
        );

      case SessionStatus.notFound:
        return Scaffold(
          body: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.wifi_off, size: 48),
                const SizedBox(height: 12),
                const Text(
                  "Couldn't find a GX router on this network.\n"
                  'Make sure your phone is connected to the router\'s Wi-Fi.',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: controller.retryDiscovery,
                  child: const Text('Retry'),
                ),
              ],
            ),
          ),
        );

      case SessionStatus.needsLogin:
        return const LoginScreen();

      case SessionStatus.authenticated:
        return const DashboardScreen();
    }
  }
}
