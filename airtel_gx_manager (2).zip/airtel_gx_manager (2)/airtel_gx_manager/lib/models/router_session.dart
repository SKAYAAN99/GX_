// router_session.dart
//
// Data models around router discovery and session state. Note:
// RouterSession itself (the stateful class that owns the http.Client
// and the ecntToken lifecycle) stays in services/router_service.dart —
// it's behavior, not data, so it doesn't belong here despite the
// filename in the original layout sketch. This file holds the DTOs
// that flow into and out of it.

class DiscoveredRouter {
  final String gatewayIp;
  final String? modelName;
  final String? firmwareVersion;

  DiscoveredRouter({
    required this.gatewayIp,
    this.modelName,
    this.firmwareVersion,
  });
}

/// The captcha token + image bytes for a login attempt. `token` is what
/// gets echoed back as the `Captcha_url` form field — it's NOT a URL by
/// the time you use it, despite the field name; it's the filename stem
/// of /captcha/<token>.gif, extracted from an inline `var Valivalue =
/// "..."` assignment in login.asp's HTML rather than a real <img> tag
/// (the tag itself is built client-side via insertAdjacentHTML).
class CaptchaChallenge {
  final String token;
  final List<int> imageBytes; // raw .gif bytes, ready for Image.memory()

  CaptchaChallenge({required this.token, required this.imageBytes});
}

class RouterAuthException implements Exception {
  /// 'locked' | 'already_logged_in' | 'bad_credentials' | 'captcha' | 'unknown'
  final String reason;
  RouterAuthException(this.reason);
}

class WifiRadioConfig {
  final String ssid;
  final bool broadcastEnabled;
  final String? securityType;

  WifiRadioConfig({
    required this.ssid,
    required this.broadcastEnabled,
    this.securityType,
  });
}
