// connected_device.dart
//
// Pure data models for the connected-clients feature. Kept free of any
// networking/parsing logic so they're safe to import from UI, service,
// and test code alike.

class ConnectedDevice {
  final String hostname;
  final String ipAddress;
  final String macAddress;
  final bool isBlocked;

  ConnectedDevice({
    required this.hostname,
    required this.ipAddress,
    required this.macAddress,
    required this.isBlocked,
  });

  ConnectedDevice copyWith({bool? isBlocked}) => ConnectedDevice(
        hostname: hostname,
        ipAddress: ipAddress,
        macAddress: macAddress,
        isBlocked: isBlocked ?? this.isBlocked,
      );
}

/// A single rule as scraped from sec_macfilterlist.cgi.
class MacFilterRule {
  final int index; // position in the list — needed for delete (delnum)
  final String name;
  final String macAddress;
  final bool enabled;

  MacFilterRule({
    required this.index,
    required this.name,
    required this.macAddress,
    required this.enabled,
  });
}

/// MAC filter mode — see mac_filter_service.dart header for why this
/// matters. denyList = "block" behaves as expected. allowList = adding
/// a rule restricts the network to just that device.
enum MacFilterMode { denyList, allowList, unknown }

/// Value the router's own ChangeMode() JS function submits for each
/// mode — confirmed directly from sec-macfilter.asp's source, not
/// guessed: `Form.ListType_Flag.value = "Black"` / `"White"`.
extension MacFilterModeWireValue on MacFilterMode {
  String get wireValue {
    switch (this) {
      case MacFilterMode.denyList:
        return 'Black';
      case MacFilterMode.allowList:
        return 'White';
      case MacFilterMode.unknown:
        throw StateError('No wire value for an unknown mode.');
    }
  }
}

class MacFilterModeMismatchException implements Exception {
  final MacFilterMode actual;
  MacFilterModeMismatchException(this.actual);
  @override
  String toString() =>
      'Refusing to add a block rule: filter is in $actual mode, not deny-list. '
      'Adding a MAC here would restrict the network to only that device.';
}
