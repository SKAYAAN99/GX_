// router_service.dart
//
// Discovery + session + parsing layer for TCLinux/Boa-based GX router
// firmware, built against the ACTUAL contract found in
// tclinux-T2122-V1_30.bin — not a generic ubus/LuCI assumption.
//
// Key facts this code encodes:
//   - Auth endpoint: POST /cgi-bin/check_auth.json (real JSON, everything
//     else is HTML/JS fragments)
//   - Session token arrives as JSON field `ecntToken`, must be resent as
//     a cookie named `ecntToken` on subsequent requests
//   - Most data-bearing endpoints (net-wlan.asp, content.asp, etc.) return
//     text/html with values embedded as tcWebApi_get(...) server-rendered
//     text or inline <script> var assignments — they must be scraped,
//     not JSON-decoded
//
// Dependencies (pubspec.yaml):
//   http: ^1.2.0
//   network_info_plus: ^5.0.0   // gateway IP / SSID detection
//   connectivity_plus: ^6.0.0   // confirm on Wi-Fi before probing

import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:network_info_plus/network_info_plus.dart';
import '../models/router_session.dart';

/// ---------------------------------------------------------------------
/// 1. AUTO-DISCOVERY
/// ---------------------------------------------------------------------
///
/// Finds the LAN gateway IP for the network the phone is currently on,
/// then confirms it's actually a GX-family router (vs. some other AP)
/// by checking for the login page fingerprint, before ever asking the
/// user for credentials.

class RouterDiscoveryService {
  final NetworkInfo _networkInfo = NetworkInfo();

  /// Returns null if the phone isn't on a Wi-Fi network, or the gateway
  /// doesn't look like a supported GX router.
  Future<DiscoveredRouter?> discover({
    Duration timeout = const Duration(seconds: 4),
  }) async {
    final gatewayIp = await _networkInfo.getWifiGatewayIP();
    if (gatewayIp == null || gatewayIp.isEmpty) return null;

    // Probe the login page directly — on this firmware family it's
    // always reachable unauthenticated at /cgi-bin/login.asp and its
    // <title> / logo markup is a cheap, stable fingerprint.
    Uri loginUri = Uri.http(gatewayIp, '/cgi-bin/login.asp');
    http.Response resp;
    try {
      _debugHttpRequest('RouterDiscoveryService.discover GET', loginUri,
          headers: null, body: null);
      resp = await http.get(loginUri).timeout(timeout);
      _debugHttpResponse('RouterDiscoveryService.discover GET', loginUri, resp);
    } catch (_) {
      // Some firmware builds only serve HTTPS with a self-signed cert.
      try {
        loginUri = Uri.https(gatewayIp, '/cgi-bin/login.asp');
        _debugHttpRequest('RouterDiscoveryService.discover GET (HTTPS fallback)',
            loginUri, headers: null, body: null);
        resp = await _getInsecure(loginUri).timeout(timeout);
        _debugHttpResponse(
            'RouterDiscoveryService.discover GET (HTTPS fallback)', loginUri, resp);
      } catch (_) {
        return null;
      }
    }

    if (resp.statusCode != 200 || !resp.body.contains('loginui')) {
      return null; // reachable, but not this firmware family
    }

    return DiscoveredRouter(
      gatewayIp: gatewayIp,
      modelName: _extractModelHint(resp.body),
      firmwareVersion: null, // only exposed post-login on content.asp
    );
  }

  // Self-signed cert tolerance for the HTTPS admin UI some GX builds
  // ship with. Only used for the LAN admin IP, never for general
  // internet traffic — scope this client narrowly in production.
  Future<http.Response> _getInsecure(Uri uri) async {
    final client = HttpClientAdapterInsecure();
    try {
      return await client.get(uri);
    } finally {
      client.close();
    }
  }

  String? _extractModelHint(String html) {
    // These builds don't expose the model on the unauthenticated login
    // page in every firmware revision — this is best-effort only.
    final match = RegExp(r'ModelName["\s:=]+([A-Za-z0-9\-]+)')
        .firstMatch(html);
    return match?.group(1);
  }
}

/// Minimal insecure-TLS http client, isolated so it's obviously scoped
/// to LAN admin traffic and easy to audit/remove.
class HttpClientAdapterInsecure {
  final _client = http.Client();
  Future<http.Response> get(Uri uri) async {
    _debugHttpRequest('HttpClientAdapterInsecure.get', uri, headers: null, body: null);
    final resp = await _client.get(uri);
    _debugHttpResponse('HttpClientAdapterInsecure.get', uri, resp);
    return resp;
  }

  void close() => _client.close();
}

String _formatHttpBody(Object? body) {
  if (body == null) return '<empty>';
  if (body is Map) {
    return body.entries
        .map((e) => '${Uri.encodeQueryComponent(e.key.toString())}=${Uri.encodeQueryComponent(e.value.toString())}')
        .join('&');
  }
  return body.toString();
}

void _debugHttpRequest(
  String label,
  Uri uri, {
  Map<String, String>? headers,
  Object? body,
}) {
  print('');
  print('=== HTTP REQUEST [$label] ===');
  print('URL: ${uri.toString()}');
  print('Headers: ${headers == null ? '<none>' : headers.toString()}');
  print('Body: ${_formatHttpBody(body)}');
  print('=============================');
}

void _debugHttpResponse(String label, Uri uri, http.Response resp) {
  final setCookie = resp.headers['set-cookie'] ?? resp.headers['Set-Cookie'];
  print('');
  print('=== HTTP RESPONSE [$label] ===');
  print('URL: ${uri.toString()}');
  print('Status Code: ${resp.statusCode}');
  print('Headers: ${resp.headers.toString()}');
  print('Set-Cookie: ${setCookie ?? '<none>'}');
  print('Body: ${resp.body}');
  print('==============================');
}

/// ---------------------------------------------------------------------
/// 2. SESSION / AUTH
/// ---------------------------------------------------------------------

class RouterSession {
  final String gatewayIp;
  final bool useHttps;
  String? _token; // ecntToken
  final http.Client _client;

  /// [httpClient] is injectable so tests can pass a MockClient
  /// (package:http/testing.dart) instead of hitting a real router.
  /// Defaults to a normal client in production.
  RouterSession({
    required this.gatewayIp,
    this.useHttps = false,
    http.Client? httpClient,
  }) : _client = httpClient ?? http.Client();

  Uri _uri(String path) => useHttps
      ? Uri.https(gatewayIp, path)
      : Uri.http(gatewayIp, path);

  String _buildCookieHeader() => _token == null ? '' : 'ecntToken=$_token';

  void _captureSessionTokenFromResponse(http.Response resp) {
    final setCookieValue = resp.headers['set-cookie'] ?? resp.headers['Set-Cookie'];
    if (setCookieValue == null || setCookieValue.isEmpty) return;

    final patterns = [
      RegExp(r'(?i)(?:^|,\s*)ecntToken\s*=\s*([^;,
\s]+)'),
      RegExp(r'(?i)(?:^|,\s*)loginToken\s*=\s*([^;,\s]+)'),
      RegExp(r'(?i)(?:^|,\s*)sessionid\s*=\s*([^;,\s]+)'),
      RegExp(r'(?i)(?:^|,\s*)token\s*=\s*([^;,\s]+)'),
    ];

    for (final pattern in patterns) {
      final match = pattern.firstMatch(setCookieValue);
      if (match != null) {
        final value = match.group(1)?.trim();
        if (value != null && value.isNotEmpty) {
          _token = value;
          return;
        }
      }
    }

    final bodyToken = RegExp(
      r'(?i)(?:ecntToken|loginToken|sessionid|token)["\'\s:=]+([^;\",\s]+)',
    ).firstMatch(resp.body);
    if (bodyToken != null) {
      final value = bodyToken.group(1)?.trim();
      if (value != null && value.isNotEmpty) {
        _token = value;
      }
    }
  }

  Map<String, dynamic>? _decodeJsonResponse(String body) {
    final trimmed = body.trim();
    if (trimmed.isEmpty || !(trimmed.startsWith('{') || trimmed.startsWith('['))) {
      return null;
    }
    try {
      final decoded = jsonDecode(trimmed);
      if (decoded is Map<String, dynamic>) return decoded;
      if (decoded is Map) return decoded.cast<String, dynamic>();
    } catch (_) {
      return null;
    }
    return null;
  }

  /// Fetches a fresh captcha challenge. Call this once when the login
  /// screen opens, and again if the user hits "refresh" (mirrors
  /// refreshself() in login.asp, which just reloads the whole page —
  /// we only need to re-run this instead).
  ///
  /// The token isn't in a normal <img> tag — see CaptchaChallenge docs.
  /// Regex against a server-rendered `var Valivalue = "...";` line.
  Future<CaptchaChallenge> fetchCaptcha() async {
    final loginUri = _uri('/cgi-bin/login.asp');
    _debugHttpRequest('RouterSession.fetchCaptcha GET', loginUri,
        headers: null, body: null);
    final pageResp = await _client.get(loginUri);
    _debugHttpResponse('RouterSession.fetchCaptcha GET', loginUri, pageResp);
    final match =
        RegExp(r'''Valivalue\s*=\s*"([^"]+)"''').firstMatch(pageResp.body);
    if (match == null) {
      throw StateError(
        'Could not find captcha token on login page — firmware layout '
        'may differ from tclinux-T2122-V1.30.',
      );
    }
    final token = match.group(1)!;
    final captchaUri = _uri('/captcha/$token.gif');
    _debugHttpRequest('RouterSession.fetchCaptcha image GET', captchaUri,
        headers: null, body: null);
    final imgResp = await _client.get(captchaUri);
    _debugHttpResponse('RouterSession.fetchCaptcha image GET', captchaUri, imgResp);
    if (imgResp.statusCode != 200) {
      throw StateError('Captcha image request failed.');
    }
    return CaptchaChallenge(token: token, imageBytes: imgResp.bodyBytes);
  }

  /// Logs in against the real /cgi-bin/check_auth.json contract.
  /// Newer GX builds sometimes switch endpoint names, response formats,
  /// or cookie naming while still speaking the same auth protocol.
  Future<void> login({
    required String username,
    required String password,
    required String captcha,
    required String captchaUrlToken,
  }) async {
    final authEndpoints = [
      '/cgi-bin/check_auth.json',
      '/cgi-bin/check_auth',
      '/cgi-bin/check_auth.cgi',
      '/cgi-bin/check_auth.asp',
    ];

    final payloads = [
      {
        'username': username,
        'password': password,
        'ValidateCode': captcha,
        'Captcha_url': captchaUrlToken,
      },
      {
        'username': username,
        'password': password,
        'captcha': captcha,
        'captcha_url': captchaUrlToken,
      },
      {
        'username': username,
        'password': password,
        'ValidateCode': captcha,
        'captcha_url': captchaUrlToken,
      },
      {
        'user': username,
        'pass': password,
        'ValidateCode': captcha,
        'Captcha_url': captchaUrlToken,
      },
    ];

    Object? lastError;

    for (final endpoint in authEndpoints) {
      final authUri = _uri(endpoint);
      for (final formBody in payloads) {
        final requestHeaders = {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Accept': 'application/json,text/plain,*/*',
        };
        _debugHttpRequest('RouterSession.login POST', authUri,
            headers: requestHeaders, body: formBody);

        try {
          final resp = await _client
              .post(
                authUri,
                headers: requestHeaders,
                body: formBody,
              )
              .timeout(const Duration(seconds: 10));
          _debugHttpResponse('RouterSession.login POST', authUri, resp);
          _captureSessionTokenFromResponse(resp);

          final json = _decodeJsonResponse(resp.body);
          if (json != null) {
            final locked = json['Locked'] ?? json['locked'];
            final logged = json['Logged'] ?? json['logged'];
            final captchaOk = json['CaptchaOK'] ?? json['Captchaok'] ?? json['captchaOK'];
            final privilege = json['Privilege'] ?? json['privilege'];
            final token = json['ecntToken'] ?? json['ecnttoken'] ?? json['token'];

            if (token is String && token.isNotEmpty) {
              _token = token;
              return;
            }
            if (locked == '1' || locked == 1) throw RouterAuthException('locked');
            if (logged == '1' || logged == '2' || logged == 1 || logged == 2) {
              throw RouterAuthException('already_logged_in');
            }
            if (captchaOk == '2' || captchaOk == 2) {
              throw RouterAuthException('captcha');
            }
            if (privilege == '0' || privilege == 0) {
              throw RouterAuthException('bad_credentials');
            }
          }

          final tokenFromBody = RegExp(
            r'(?i)(?:ecntToken|loginToken|sessionid|token)[\"\'\s:=]+([^;\",\s]+)',
          ).firstMatch(resp.body);
          if (tokenFromBody != null && (tokenFromBody.group(1) ?? '').isNotEmpty) {
            _token = tokenFromBody.group(1)!;
            return;
          }

          if (resp.statusCode == 200 &&
              (resp.body.contains('loginui') ||
                  resp.body.contains('login.asp') ||
                  resp.body.contains('Login'))) {
            continue;
          }

          if (resp.statusCode == 200) {
            final bodyText = resp.body.toLowerCase();
            if (bodyText.contains('wrong password') ||
                bodyText.contains('invalid') ||
                bodyText.contains('failed') ||
                bodyText.contains('incorrect')) {
              throw RouterAuthException('bad_credentials');
            }
          }

          if (resp.statusCode != 200) {
            continue;
          }
        } catch (e) {
          lastError = e;
          if (e is RouterAuthException) rethrow;
        }
      }
    }

    if (lastError is RouterAuthException) {
      throw lastError;
    }
    throw RouterAuthException('unknown');
  }

  bool get isAuthenticated => _token != null;

  /// Fetches an authenticated fragment endpoint (e.g. content.asp,
  /// net-wlan.asp) with the session cookie attached. Returns the raw
  /// HTML/JS body for the fragment parser layer to consume.
  Future<String> fetchFragment(String cgiPath) async {
    if (_token == null) {
      throw StateError('Not authenticated — call login() first.');
    }
    final fragmentUri = _uri(cgiPath);
    final requestHeaders = {'Cookie': _buildCookieHeader()};
    _debugHttpRequest('RouterSession.fetchFragment GET', fragmentUri,
        headers: requestHeaders, body: null);
    final resp = await _client.get(
      fragmentUri,
      headers: requestHeaders,
    );
    _debugHttpResponse('RouterSession.fetchFragment GET', fragmentUri, resp);
    _captureSessionTokenFromResponse(resp);
    if (resp.statusCode == 302 || resp.body.contains('loginui')) {
      _token = null;
      throw StateError('Session expired.');
    }
    return resp.body;
  }

  /// Submits a form POST with the session cookie attached — used for
  /// every write action (MAC filter add/delete, Wi-Fi save, reboot).
  /// Returns the raw response body for the caller to inspect, since
  /// these endpoints reply with HTML/JS fragments, not status JSON.
  Future<String> postForm(String cgiPath, Map<String, String> fields) async {
    if (_token == null) {
      throw StateError('Not authenticated — call login() first.');
    }
    final formUri = _uri(cgiPath);
    final requestHeaders = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Cookie': _buildCookieHeader(),
    };
    _debugHttpRequest('RouterSession.postForm POST', formUri,
        headers: requestHeaders, body: fields);
    final resp = await _client.post(
      formUri,
      headers: requestHeaders,
      body: fields,
    );
    _debugHttpResponse('RouterSession.postForm POST', formUri, resp);
    _captureSessionTokenFromResponse(resp);
    if (resp.statusCode == 302 || resp.body.contains('loginui')) {
      _token = null;
      throw StateError('Session expired.');
    }
    return resp.body;
  }

  void dispose() => _client.close();
}

/// ---------------------------------------------------------------------
/// 3. FRAGMENT PARSING
/// ---------------------------------------------------------------------
///
/// Each data-bearing endpoint gets a small, testable parser instead of
/// one giant regex pile. Keep an HTML fixture per firmware version in
/// your test suite and run these against it in CI — this layer is the
/// thing that will break silently across firmware revisions.

class WlanFragmentParser {
  /// Parses the fragment returned by GET /cgi-bin/net-wlan.asp
  /// (authenticated).
  ///
  /// CORRECTION from an earlier version of this file: I'd previously
  /// guessed the field names as name="SSID" / name="EnableSSID" /
  /// name="EncryptionType". Checking the actual extracted net-wlan.asp
  /// against the firmware dump shows that's wrong — the static HTML
  /// only contains hidden fields (henableSsid, SSID_Flag, SSIDPre) and
  /// RADIUS/WDS controls. The visible SSID text input isn't in the
  /// page's static markup at all — like the login captcha, it appears
  /// to be constructed client-side by JS at runtime from a
  /// tcWebApi_get(...) call, which a static firmware dump can't show.
  ///
  /// The regexes below are placeholders preserving the intended
  /// extraction shape, not confirmed field names. Do not ship this
  /// against production traffic without replacing them from an actual
  /// authenticated capture of net-wlan.asp's runtime-rendered DOM
  /// (e.g. via a WebView + JS evaluation, or a proxy capture of any
  /// XHR the page fires after load) — this is a bigger gap than the
  /// mac-filter or auth flows, which I did confirm against the dump.
  static WifiRadioConfig? parse(String html) {
    final ssidMatch =
        RegExp(r'name="SSID"[^>]*value="([^"]*)"').firstMatch(html);
    final enabledMatch =
        RegExp(r'name="EnableSSID"[^>]*checked').firstMatch(html);
    final securityMatch =
        RegExp(r'name="EncryptionType"[^>]*value="([^"]*)"\s*selected')
            .firstMatch(html);

    if (ssidMatch == null) return null; // not this endpoint / firmware

    return WifiRadioConfig(
      ssid: ssidMatch.group(1) ?? '',
      broadcastEnabled: enabledMatch != null,
      securityType: securityMatch?.group(1),
    );
  }
}

/// ---------------------------------------------------------------------
/// 4. FIRMWARE ADAPTER REGISTRY
/// ---------------------------------------------------------------------
///
/// Selects a parser set by fingerprint instead of assuming one schema
/// works across every GX firmware build.

abstract class FirmwareAdapter {
  String get id;
  WifiRadioConfig? parseWlan(String html);
}

class AdapterTclinuxV1_30 implements FirmwareAdapter {
  @override
  String get id => 'tclinux-T2122-V1.30';
  @override
  WifiRadioConfig? parseWlan(String html) => WlanFragmentParser.parse(html);
}

class FirmwareAdapterRegistry {
  final List<FirmwareAdapter> _adapters = [AdapterTclinuxV1_30()];

  FirmwareAdapter resolve(String? firmwareHint) {
    if (firmwareHint != null) {
      for (final a in _adapters) {
        if (firmwareHint.contains(a.id.split('-').last)) return a;
      }
    }
    // Fall back to the most recent known adapter; log this case loudly
    // in production so unsupported firmware gets flagged, not silently
    // mis-parsed.
    return _adapters.last;
  }
}
