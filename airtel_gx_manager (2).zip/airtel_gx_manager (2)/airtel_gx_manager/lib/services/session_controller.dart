// session_controller.dart
//
// App-level state machine: discovery -> login -> authenticated. This is
// the thing main.dart listens to via Provider to decide which screen
// to show. Kept separate from RouterSession itself so the low-level
// HTTP/cookie logic stays testable without Flutter in the picture.

import 'package:flutter/foundation.dart';
import '../models/router_session.dart';
import 'router_service.dart';

enum SessionStatus { discovering, notFound, needsLogin, authenticated }

class SessionController extends ChangeNotifier {
  final RouterDiscoveryService _discovery = RouterDiscoveryService();

  SessionStatus status = SessionStatus.discovering;
  DiscoveredRouter? discoveredRouter;
  RouterSession? session;
  String? lastError;

  SessionController() {
    _runDiscovery();
  }

  Future<void> _runDiscovery() async {
    status = SessionStatus.discovering;
    lastError = null;
    notifyListeners();

    final router = await _discovery.discover();
    if (router == null) {
      status = SessionStatus.notFound;
      notifyListeners();
      return;
    }

    discoveredRouter = router;
    session = RouterSession(gatewayIp: router.gatewayIp);
    status = SessionStatus.needsLogin;
    notifyListeners();
  }

  Future<void> retryDiscovery() => _runDiscovery();

  Future<bool> login({
    required String username,
    required String password,
    required String captcha,
    required String captchaUrlToken,
  }) async {
    if (session == null) return false;
    lastError = null;
    try {
      await session!.login(
        username: username,
        password: password,
        captcha: captcha,
        captchaUrlToken: captchaUrlToken,
      );
      status = SessionStatus.authenticated;
      notifyListeners();
      return true;
    } on RouterAuthException catch (e) {
      lastError = _messageFor(e.reason);
      notifyListeners();
      return false;
    } catch (_) {
      lastError = 'Could not reach the router. Check your Wi-Fi connection.';
      notifyListeners();
      return false;
    }
  }

  void logout() {
    session?.dispose();
    if (discoveredRouter != null) {
      session = RouterSession(gatewayIp: discoveredRouter!.gatewayIp);
    }
    status = SessionStatus.needsLogin;
    notifyListeners();
  }

  String _messageFor(String reason) {
    switch (reason) {
      case 'locked':
        return 'Too many failed attempts. Try again in a minute.';
      case 'already_logged_in':
        return 'Another session is already logged in on this router.';
      case 'bad_credentials':
        return 'Incorrect username or password.';
      case 'captcha':
        return 'Captcha didn\'t match — try again.';
      default:
        return 'Login failed. Please try again.';
    }
  }

  @override
  void dispose() {
    session?.dispose();
    super.dispose();
  }
}
