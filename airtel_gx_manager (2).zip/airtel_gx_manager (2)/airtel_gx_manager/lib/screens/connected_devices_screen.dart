// connected_devices_screen.dart
//
// Connected device list with 1-tap block/unblock. The safety modal for
// MacFilterModeMismatchException is the important part of this file —
// see _showModeMismatchDialog below.

import 'package:flutter/material.dart';
import '../services/mac_filter_service.dart';
import '../services/router_service.dart' show RouterSession;
import '../models/connected_device.dart';
import '../theme/app_theme.dart';

class ConnectedDevicesScreen extends StatefulWidget {
  final RouterSession session;

  const ConnectedDevicesScreen({super.key, required this.session});

  @override
  State<ConnectedDevicesScreen> createState() =>
      _ConnectedDevicesScreenState();
}

class _ConnectedDevicesScreenState extends State<ConnectedDevicesScreen> {
  late final MacFilterService _service;

  List<ConnectedDevice> _devices = [];
  bool _loading = true;
  String? _error;
  final Set<String> _pendingMacs = {};

  // Schema-audit state: populated if get_device_details.json returns
  // keys the normalizer couldn't map to mac/hostname/ip. Surfaced as a
  // banner rather than staying silent — an unmapped-keys situation
  // otherwise looks identical to "no devices connected".
  final Set<String> _unmappedSchemaKeys = {};
  bool _schemaWarningDismissed = false;

  @override
  void initState() {
    super.initState();
    // Built here (not as a field initializer) because the callback
    // needs `setState`, which isn't available until State exists.
    _service = MacFilterService(
      widget.session,
      onUnmappedSchemaKeys: (keys) {
        if (!mounted) return;
        setState(() => _unmappedSchemaKeys.addAll(keys));
      },
    );
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
      // Clear prior audit state on every load — a refresh after a
      // schema fix (or a firmware update) shouldn't leave a stale
      // warning from the last run.
      _unmappedSchemaKeys.clear();
      _schemaWarningDismissed = false;
    });
    try {
      final devices = await _service.getConnectedDevices();
      setState(() {
        _devices = devices;
        _loading = false;
      });
    } catch (_) {
      setState(() {
        _error = 'Could not load connected devices.';
        _loading = false;
      });
    }
  }

  Future<void> _toggleBlock(ConnectedDevice device) async {
    setState(() => _pendingMacs.add(device.macAddress));

    final originalIndex = _devices.indexOf(device);
    setState(() {
      _devices[originalIndex] = device.copyWith(isBlocked: !device.isBlocked);
    });

    try {
      if (device.isBlocked) {
        await _service.unblockDevice(device.macAddress);
      } else {
        await _service.blockDevice(
          name: device.hostname,
          macAddress: device.macAddress,
        );
      }
    } on MacFilterModeMismatchException catch (_) {
      _revert(originalIndex, device);
      if (mounted) await _showModeMismatchDialog();
    } on StateError catch (e) {
      _revert(originalIndex, device);
      _showError('Session expired', e.message.isNotEmpty
          ? e.message
          : 'Please log in again to continue.');
    } catch (_) {
      _revert(originalIndex, device);
      _showError(
        'Action failed',
        "Could not update this device. It may not be supported on this "
            "router's firmware version.",
      );
    } finally {
      if (mounted) setState(() => _pendingMacs.remove(device.macAddress));
    }
  }

  void _revert(int index, ConnectedDevice original) {
    if (mounted) setState(() => _devices[index] = original);
  }

  void _showError(String title, String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  /// The safety modal. Explains the situation plainly, and only offers
  /// the mode switch behind its own explicit, separate confirmation —
  /// this dialog's "Switch to Deny-List Mode" button does NOT itself
  /// call switchFilterMode(confirmed: true); it opens a second,
  /// harder-to-misclick confirmation step first. Two dialogs, not one,
  /// on purpose: this is the exact action that can lock a whole network
  /// down to one device if done carelessly.
  Future<void> _showModeMismatchDialog() async {
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        icon: const Icon(Icons.warning_amber_rounded,
            color: AppColors.warning, size: 32),
        title: const Text('Router is in Allow-List mode'),
        content: const Text(
          "This router's access control is currently set to only allow "
          'listed devices onto the network — not to block them.\n\n'
          "Blocking a device here requires switching to Deny-List mode "
          'first. Any devices currently on the allow-list will no longer '
          'be treated specially once you do — every device will be '
          'allowed by default except the ones you explicitly block.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: AppColors.warning,
            ),
            onPressed: () {
              Navigator.of(ctx).pop();
              _confirmAndSwitchMode();
            },
            child: const Text('Switch to Deny-List Mode'),
          ),
        ],
      ),
    );
  }

  /// The second, explicit confirmation — mirrors the router's own web
  /// UI, which gates this exact action behind a JS confirm() dialog.
  Future<void> _confirmAndSwitchMode() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Confirm mode switch'),
        content: const Text(
          'This changes how the router treats every device on your '
          'network, not just the one you tapped. Are you sure?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.blocked),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Yes, switch mode'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      await _service.switchFilterMode(
        targetMode: MacFilterMode.denyList,
        confirmed: true,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Switched to Deny-List mode.')),
        );
      }
    } catch (e) {
      if (mounted) {
        _showError('Mode switch failed',
            'The router did not confirm the change. Please check its '
            'settings directly before trying again.');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Connected Devices')),
      body: _error != null
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(_error!),
                  const SizedBox(height: 12),
                  ElevatedButton(onPressed: _load, child: const Text('Retry')),
                ],
              ),
            )
          : Column(
              children: [
                if (_unmappedSchemaKeys.isNotEmpty && !_schemaWarningDismissed)
                  _SchemaWarningBanner(
                    unmappedKeys: _unmappedSchemaKeys,
                    onDismiss: () =>
                        setState(() => _schemaWarningDismissed = true),
                  ),
                Expanded(
                  child: RefreshIndicator(
                    onRefresh: _load,
                    child: ListView.separated(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      itemCount: _devices.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, i) {
                        final device = _devices[i];
                        final isPending =
                            _pendingMacs.contains(device.macAddress);

                        return ListTile(
                          leading: CircleAvatar(
                            backgroundColor: device.isBlocked
                                ? AppColors.blocked.withValues(alpha: 0.1)
                                : AppColors.online.withValues(alpha: 0.1),
                            child: Icon(
                              device.isBlocked ? Icons.block : Icons.devices,
                              color: device.isBlocked
                                  ? AppColors.blocked
                                  : AppColors.online,
                            ),
                          ),
                          title: Text(
                            device.hostname.isEmpty
                                ? 'Unknown device'
                                : device.hostname,
                            style: const TextStyle(fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text(
                              '${device.ipAddress}\n${device.macAddress}'),
                          isThreeLine: true,
                          trailing: isPending
                              ? const SizedBox(
                                  width: 24,
                                  height: 24,
                                  child:
                                      CircularProgressIndicator(strokeWidth: 2),
                                )
                              : Switch(
                                  value: !device.isBlocked,
                                  onChanged: (_) => _toggleBlock(device),
                                ),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

/// Diagnostic banner for the schema-audit gap flagged at the end of the
/// previous session: an unmapped-keys situation used to look identical
/// to "no devices connected" — this makes it visible instead.
class _SchemaWarningBanner extends StatelessWidget {
  final Set<String> unmappedKeys;
  final VoidCallback onDismiss;

  const _SchemaWarningBanner({
    required this.unmappedKeys,
    required this.onDismiss,
  });

  @override
  Widget build(BuildContext context) {
    final sample = unmappedKeys.take(6).join(', ');
    final more = unmappedKeys.length > 6
        ? ' (+${unmappedKeys.length - 6} more)'
        : '';

    return MaterialBanner(
      backgroundColor: AppColors.warning.withValues(alpha: 0.12),
      leading: const Icon(Icons.warning_amber_rounded, color: AppColors.warning),
      content: Text(
        'The device list returned fields this app doesn\'t recognize yet: '
        '$sample$more. Some device info may be missing or incorrect until '
        'the app is updated for this firmware.',
        style: const TextStyle(fontSize: 13),
      ),
      actions: [
        TextButton(onPressed: onDismiss, child: const Text('Dismiss')),
      ],
    );
  }
}
