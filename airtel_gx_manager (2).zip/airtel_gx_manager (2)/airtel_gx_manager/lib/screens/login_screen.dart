// login_screen.dart

import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/router_session.dart';
import '../services/session_controller.dart';
import '../theme/app_theme.dart';
import 'dashboard_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _usernameController = TextEditingController(text: 'admin');
  final _passwordController = TextEditingController();
  final _captchaController = TextEditingController();

  CaptchaChallenge? _captcha;
  bool _loadingCaptcha = true;
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadCaptcha());
  }

  Future<void> _loadCaptcha() async {
    setState(() => _loadingCaptcha = true);
    final controller = context.read<SessionController>();
    try {
      final captcha = await controller.session!.fetchCaptcha();
      setState(() {
        _captcha = captcha;
        _loadingCaptcha = false;
      });
    } catch (_) {
      setState(() => _loadingCaptcha = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not load captcha. Retry?')),
        );
      }
    }
  }

  Future<void> _submit() async {
    if (_captcha == null) return;
    setState(() => _submitting = true);

    final controller = context.read<SessionController>();
    final success = await controller.login(
      username: _usernameController.text.trim(),
      password: _passwordController.text,
      captcha: _captchaController.text.trim(),
      captchaUrlToken: _captcha!.token,
    );

    setState(() => _submitting = false);

    if (!success) {
      // Failed attempts consume the captcha on this firmware (mirrors
      // the "Refresh" flow in login.asp after a bad attempt) — fetch a
      // new one rather than letting the user retry a stale token.
      _captchaController.clear();
      await _loadCaptcha();
      if (mounted && controller.lastError != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(controller.lastError!),
            backgroundColor: AppColors.blocked,
          ),
        );
      }
      return;
    }

    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const DashboardScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final router = context.watch<SessionController>().discoveredRouter;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 360),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Corporate ISP header block — brand mark + name,
                    // no AI-assistant visual language.
                    Container(
                      width: 72,
                      height: 72,
                      decoration: BoxDecoration(
                        color: AppColors.navy,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Icon(
                        Icons.router,
                        color: Colors.white,
                        size: 36,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'GIC Broadband',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                        color: AppColors.navy,
                      ),
                    ),
                    Text(
                      router?.modelName ?? 'Router Manager',
                      style: TextStyle(color: Colors.grey.shade600),
                    ),
                    if (router != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        router.gatewayIp,
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey.shade500,
                        ),
                      ),
                    ],
                    const SizedBox(height: 32),

                    TextField(
                      controller: _usernameController,
                      decoration: const InputDecoration(
                        labelText: 'Username',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _passwordController,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'Password',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 16),

                    if (_loadingCaptcha)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: CircularProgressIndicator(),
                      )
                    else if (_captcha != null) ...[
                      ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: Image.memory(
                          Uint8List.fromList(_captcha!.imageBytes),
                          height: 60,
                          width: 160,
                          gaplessPlayback: true,
                        ),
                      ),
                      TextButton(
                        onPressed: _loadCaptcha,
                        child: const Text('Refresh captcha'),
                      ),
                    ],
                    TextField(
                      controller: _captchaController,
                      decoration: const InputDecoration(
                        labelText: 'Enter captcha',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 24),

                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _submitting ? null : _submit,
                        child: _submitting
                            ? const SizedBox(
                                height: 18,
                                width: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Text('Log in'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
