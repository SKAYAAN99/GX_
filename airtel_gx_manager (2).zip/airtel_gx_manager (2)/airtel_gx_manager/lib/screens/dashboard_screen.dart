// dashboard_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../theme/app_theme.dart';
import '../services/session_controller.dart';
import '../widgets/dashboard_feature_card.dart';
import 'connected_devices_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<SessionController>();
    final router = controller.discoveredRouter;
    final session = controller.session;

    // Config list — this is the thing you extend for Speed Test, Port
    // Forwarding, Parental Controls, etc. Each entry is one line; the
    // grid and card layout don't change.
    final features = <DashboardFeatureConfig>[
      DashboardFeatureConfig(
        title: 'Connected Devices',
        icon: Icons.devices_other,
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => ConnectedDevicesScreen(session: session!),
            ),
          );
        },
      ),
      const DashboardFeatureConfig(
        title: 'Wi-Fi Settings',
        icon: Icons.wifi,
        onTap: _noop,
        enabled: false,
        disabledLabel: 'Coming soon',
      ),
      const DashboardFeatureConfig(
        title: 'System Reboot',
        icon: Icons.restart_alt,
        onTap: _noop,
        enabled: false,
        disabledLabel: 'Coming soon',
      ),
      // Future: Speed Test, Port Forwarding, Parental Controls — append
      // here, no other file needs to change for the grid to grow.
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('GIC Broadband'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: controller.logout,
            tooltip: 'Log out',
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: controller.retryDiscovery,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _RouterStatusCard(
              gatewayIp: router?.gatewayIp ?? '—',
              modelName: router?.modelName,
            ),
            const SizedBox(height: 20),
            Text(
              'MANAGE',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.1,
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 8),
            DashboardFeatureGrid(features: features),
          ],
        ),
      ),
    );
  }

  static void _noop() {}
}

class _RouterStatusCard extends StatelessWidget {
  final String gatewayIp;
  final String? modelName;

  const _RouterStatusCard({required this.gatewayIp, this.modelName});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: AppColors.navy,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.router, color: Colors.white),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    modelName ?? 'GX Router',
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                      color: AppColors.navy,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    gatewayIp,
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                ],
              ),
            ),
            Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: AppColors.online,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                const Text(
                  'Online',
                  style: TextStyle(
                    color: AppColors.online,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
